// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 


import java.io.IOException;
import common.ChatIF;
import ocsf.server.*;

/**
 * This class overrides some of the methods in the abstract 
 * superclass in order to give more functionality to the server.
 *
 * @author Dr Timothy C. Lethbridge
 * @author Dr Robert Lagani&egrave;re
 * @author Fran&ccedil;ois B&eacute;langer
 * @author Paul Holden
 * @version July 2000
 */
public class EchoServer extends AbstractServer 
{
  //Class variables *************************************************
  
  /**
   * The default port to listen on.
   */
  final public static int DEFAULT_PORT = 5555;
  String loginKey = "loginID";
  
  ChatIF serverUI;
  //Constructors ****************************************************
  
  /**
   * Constructs an instance of the echo server.
   *
   * @param port The port number to connect on.
   */
  public EchoServer(int port, ChatIF serverUI) 
  {
    super(port);
    this.serverUI = serverUI;
  }

  
  public EchoServer(int port) {
	  super(port);
	// TODO Auto-generated constructor stub
}


//Instance methods ************************************************
  
  /**
   * This method handles any messages received from the client.
   *
   * @param msg The message received from the client.
   * @param client The connection from which the message originated.
   */
  public void handleMessageFromClient
    (Object msg, ConnectionToClient client)
  {
    System.out.println("Message received: " + msg + " from " + client);
    this.sendToAllClients(msg);
  }
    
  /**
   * This method overrides the one in the superclass.  Called
   * when the server starts listening for connections.
   */
  protected void serverStarted()
  {
    System.out.println
      ("Server listening for connections on port " + getPort());
  }
  
  /**
   * This method overrides the one in the superclass.  Called
   * when the server stops listening for connections.
   */
  protected void serverStopped()
  {
    System.out.println
      ("Server has stopped listening for connections.");
  }
  
  
 @Override
  protected void clientConnected(ConnectionToClient client) {
	  System.out.println( client + " connected");
  }
  
  @Override
  protected synchronized void clientDisconnected(ConnectionToClient client) {
	  super.clientDisconnected(client);
  }
  
  @Override
  protected synchronized void clientException(ConnectionToClient client, Throwable exception) {
	  System.out.println("Client disconnected");
  }
  
  public void quit()
  {
    try
    {
      close();
    }
    catch(Exception e) {}
    System.exit(0);
  }
  
  
  public void handleMessageFromServerUI(String msg) {
	  serverUI.display(msg);
	  sendToAllClients(msg);
  }

  
  
	public static void main(String[] args) 
	  {
	    int port = 0; //Port to listen on

	    try
	    {
	      port = Integer.parseInt(args[0]); //Get port from command line
	    }
	    catch(Throwable t)
	    {
	      port = DEFAULT_PORT; //Set port to 5555
	    }
		
	    EchoServer sv = new EchoServer(port);
	    
	    try {
	    	sv.listen();
	    } catch (Exception ex) {
	    	System.out.println("Error!");
	    }
	   
	  }
}




//End of EchoServer class




