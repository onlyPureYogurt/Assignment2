import java.io.IOException;
import java.util.Scanner;

import common.ChatIF;

public class ServerConsole implements ChatIF {
	
	final public static int DEFAULT_PORT = 5555;
	
	EchoServer server;
	
	Scanner fromServer; 
	
	public ServerConsole(int port) {
		try {
			server = new EchoServer(port, this);
			server.listen();
		} catch (IOException exception) {
			System.out.println("Error: Can't setup connection!"
	                + " Terminating Server.");
	      System.exit(1);
		}
		fromServer = new Scanner(System.in); 
	}
	
	public void accept() {
	    try {
	      String message;
	      while (true) {
	        message = fromServer.nextLine();
	        if (message.equals("#quit")) {
	        	server.quit();
	        } else if (message.equals("#stop")) {
	        	server.stopListening();
	        } else if (message.equals("#close")) {
	        	server.close();
	        } else if (message.equals("#setport")) {
	        	if (server.isListening()) {
	        		System.out.println("Error, server still listening");
	        } else {
	        	try {
	        		int port = Integer.parseInt(message.split(" ")[1]);
	        		server.setPort(port);
	        	} catch (ArrayIndexOutOfBoundsException e) {
	        		System.out.println("port name required");
	        	} catch (NumberFormatException e) {
	        		System.out.println("Error, invalid number");
	        	}
	        }
	      } else if (message.equals("#start")) {
	    	  server.listen();
	      } else if (message.equals("#getport")) {
	    	  System.out.println(server.getPort());
	      } else {
	    	  server.handleMessageFromServerUI(message);
	      }
	    }
	      } catch (Exception ex) {
	    	  //ex.printStackTrace();
	    	  System.out.println("Unexpected error while reading from console!");
	    }
	  }

	
	@Override
	public void display(String message) {
	    System.out.println("SERVER MSG > " + message);
	  }
	
	public static void main(String[] args) 
	  {
	    int port = 0; //Port to listen on

	    try
	    {
	      port = Integer.parseInt(args[0]); //Get port from command line
	    }
	    catch(Throwable t)
	    {
	      port = DEFAULT_PORT; //Set port to 5555
	    }
		
	    ServerConsole serverconsole = new ServerConsole(port);
	    serverconsole.accept();

	  }
	}

